//
//  AOV_KDApp.swift
//  AOV KD
//
//  Created by anhvu on 5/10/25.
//

import SwiftUI

@main
struct AOV_KDApp: App {
    @StateObject var logStore = LogStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(logStore)
        }
    }
}



